<?php
 
namespace VM\SimpleNews\Block\Adminhtml\News;
 
use Magento\Backend\Block\Widget\Grid as WidgetGrid;
 
class Grid extends WidgetGrid
{
   
}